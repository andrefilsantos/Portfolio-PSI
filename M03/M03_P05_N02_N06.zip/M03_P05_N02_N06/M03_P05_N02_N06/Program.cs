﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//© André Santos && Daniel Borges, 2014
namespace M03_P05_N02_N06
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Para que cidade foi? ");
            string cidade = Console.ReadLine();            
            Console.Write("Já agora, pode informar qual o consumo médio do seu veiculo aos 100km? ");
            byte consumo = Convert.ToByte(Console.ReadLine());
            cenas(cidade, consumo);
        }
        static void cenas(string cidade, int consumo)
        {
            int distancia;
            int consumo_litros;
            switch (cidade.ToUpper())
            {
                case "BELGRADO":
                    distancia = 2895;
                    break;
                case "BUDAPESTE":
                    distancia = 2833;
                    break;
                case "MURMANSK":
                    distancia = 6309;
                    break;
                case "ESTOCOLMO":
                    distancia = 7118;
                    break;
                case "TURIM":
                    distancia = 1776;
                    break;
                default:
                    distancia = 120;
                    Console.WriteLine("Não tenho dados");
                    break;
            }
            Console.WriteLine("A distancia é: {0} km", distancia);
            consumo_litros = (consumo / 100) * distancia;
            Console.WriteLine("Vai gastar {0} litros de combustível...", consumo_litros);
        }
    }
}
