﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M06_Pxxx_N02
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declarar uma fila (FIFO)
            Queue<char> letras = new Queue<char>();

            //Adicionar um elemento à fila
            letras.Enqueue('A');
            letras.Enqueue('N');
            letras.Enqueue('D');
            letras.Enqueue('R');
            letras.Enqueue('É');

            //Mostrar o elemento que está para sair
            Console.WriteLine("O número que está para sair é " + letras.Peek());

            foreach (char item in letras)
            {
                Console.WriteLine(item);
            }

            //Como retirar o elemento que está para sair
            letras.Dequeue();
            Console.WriteLine();
            foreach (char item in letras)
            {
                Console.WriteLine(item);
            }

        }
    }
}
